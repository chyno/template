import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { ItemsComponent } from './items.component';
import { ItemDetailsComponent } from './item-details.component';
import {ItemRepositoryService} from './item-repository.service';
import { ClarityModule } from "@clr/angular";
@NgModule({
  imports: [ RouterModule, SharedModule, ClarityModule ],
  declarations: [ ItemsComponent, ItemDetailsComponent ],
  exports: [ ],
  providers: [ ItemRepositoryService ]
})
export class ItemModule { };
