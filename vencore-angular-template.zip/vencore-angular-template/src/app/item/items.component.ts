import { Component, OnInit } from '@angular/core';
import {ItemRepositoryService} from './item-repository.service';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {

  classes:any[];

  constructor(
    private itemRepository:ItemRepositoryService 
  ) {}

  ngOnInit() {
    this.itemRepository.geItems()
    .subscribe(classes => { this.classes = classes;});
  }

}
