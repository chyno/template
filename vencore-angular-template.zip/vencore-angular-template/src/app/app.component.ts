import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    styles: [`
      .app {
        width: 1000px;
        margin: auto;
      }
      .main {
        background-color:white;      
      }
    `],
    template: `
      <div class="approot2">
      <div class="applicationGrid">
          <div class="headerBar">
            <a class="navigateLink" routerLink="/search" routerLinkActive="active" style="text-decoration-line: none;">
              <img class="govLogo" width="100" height="100" src="../assets/vencore-logo.png" alt="Department of Homeland Security Logo">
            </a>
          </div>
        <div class="applicationPage">
          <router-outlet></router-outlet>
        </div>
      </div>
    </div>
   
    `,
})
export class AppComponent  {  }