import { Component, OnInit } from '@angular/core';
import {ItemRepositoryService} from './item-repository.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {
   item : any;
  constructor(private itemRepository:ItemRepositoryService,private route : ActivatedRoute,  private router: Router) {
    this.route.params.subscribe(params => console.log(params));
  }

  ngOnInit() {
    this.itemRepository.getItem(this.getUrlId())
    .subscrib(item => {
      this.item = item;
    })
  }

  getUrlId() {
    let id = "";

    this.route.params.forEach((params: Params) => {
      if (params['id'] !== undefined) {
         id = params['id'].toString();

      } else {
        console.log('a invalid code was sent');
      }
    });

    return id;
  }
}
