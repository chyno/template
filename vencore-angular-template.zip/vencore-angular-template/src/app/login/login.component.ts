import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";

@Component({
  moduleId: module.id.toString(),
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  model: any = {};
  loading = false;
  returnUrl: string;

  constructor(private route: ActivatedRoute, private router: Router) {}

  ngOnInit() {
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams["returnUrl"] || "/";
  }

  login() {
    this.loading = true;
    if (this.returnUrl === null || this.returnUrl.length < 2) {
      //Todo: Do not hard code routes
      this.router.navigate(["/items"]);
    } else {
      this.router.navigate([this.returnUrl]);
    }
  }
}
