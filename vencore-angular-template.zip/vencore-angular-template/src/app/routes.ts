import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ItemsComponent } from "./item/items.component";
import { ItemDetailsComponent } from "./item/item-details.component";


export const appRoutes : Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full'  },
  { path: 'login', component: LoginComponent },
  { path: 'items', component: ItemsComponent },
  { path: 'item-details/:id', component: ItemDetailsComponent },

 // otherwise redirect to home
 { path: '**', redirectTo: '/login' }
];
